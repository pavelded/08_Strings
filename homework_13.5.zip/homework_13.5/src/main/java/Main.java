import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.*;

public class Main {

    public static void main(String[] args) {

        try {
            Document doc = Jsoup.connect("https://www.moscowmap.ru/metro.html#lines").maxBodySize(0).get();
            Writer writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream("html/metromsc.html"), "utf-8"));
            writer.write(doc.toString());

            Elements linesParse = doc.select("span[class^=js-metro-line]");

            Elements stationsParse = doc.select("div[class^=js-metro-stations]");

            JSONObject allLines = new JSONObject();
            JSONArray linesArray = new JSONArray();

            JSONObject allStations = new JSONObject();
            JSONObject allStationsPerLine = new JSONObject();

            for (int i = 0; i < linesParse.size(); i++) {
                for (int j = 0; j < 1; j++) {
                    JSONObject lines = new JSONObject();
                    lines.put("number", linesParse.get(i).attr("data-line"));
                    lines.put("name", linesParse.get(i).text());
                    linesArray.add(lines);
                }
            }
            allLines.put("lines", linesArray);

            for (int i = 0; i < stationsParse.size(); i++) {
                JSONObject line = (JSONObject) linesArray.get(i);
                JSONArray stationsPerLine = new JSONArray();
                String lineForParse = (String) line.get("number");
                Elements stationsParsePerLine = stationsParse.select("div[data-line=" + lineForParse + "]").select("span[class^=name]");
                for (int j = 0; j < stationsParsePerLine.size(); j++) {
                    stationsPerLine.add(stationsParsePerLine.get(j).text());
                }
                allStationsPerLine.put(line.get("number"), stationsPerLine);
            }
            allStations.put("stations", allStationsPerLine);

            Writer jsonWriter = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream("src/main/files/mscMetroMap.json"), "utf-8"));
            allStations.writeJSONString(jsonWriter);
            jsonWriter.flush();

            allLines.writeJSONString(jsonWriter);
            jsonWriter.flush();
            jsonWriter.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
