import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class Main {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/skillbox_sql_dump";
        String user = "newuser";
        String pass = "323645215Ab";
        Properties p = new Properties();
        p.setProperty("user",user);
        p.setProperty("password",pass);
        p.setProperty("useUnicode","true");
        p.setProperty("encoding","utf8");
        p.setProperty("characterEncoding","utf8");


        try {
            System.out.println("Driver loaded!");

            String query = "SELECT p.course_name, count(p.subscription_date) / (max(month(p.subscription_date)) - min(month(p.subscription_date)) + 1)" +
                    " FROM purchaselist p" +
                    " WHERE year(p.subscription_date) = 2018" +
                    " GROUP by p.course_name;";

            Connection connection = DriverManager.getConnection(url, user, pass);
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);

                while (resultSet.next()) {
                    System.out.println(resultSet.getString(1) + " " + resultSet.getString(2));
                }
        } catch (Exception ex) {
            ex.printStackTrace();
        }


    }
}
