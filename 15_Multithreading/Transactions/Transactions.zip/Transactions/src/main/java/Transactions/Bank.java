package Transactions;

import java.util.Map;
import java.util.Random;

public class Bank {

    private Map<String, Account> accounts;
    private final Random random = new Random();

    public Bank(Map<String, Account> accounts) {
        this.accounts = accounts;
    }

    public synchronized boolean isFraud(String fromAccountNum, String toAccountNum, long amount)
        throws InterruptedException {
        Thread.sleep(1000);
        return random.nextBoolean();
    }

    public void transfer(String fromAccountNum, String toAccountNum, long amount) {
        if (getBalance(fromAccountNum) < amount) {
            System.out.println("Недостаточно средств для снятия");
        }
        if (accounts.get(fromAccountNum).isBlocked() || accounts.get(toAccountNum).isBlocked()) {
            System.out.println("Аккаунт заблокирован");
        }
        accounts.get(fromAccountNum).setMoney(accounts.get(fromAccountNum).getMoney() - amount);
        accounts.get(toAccountNum).setMoney(accounts.get(toAccountNum).getMoney() + amount);

        if (amount > 50000) {
            try {
                if (isFraud(fromAccountNum, toAccountNum, amount)) {
                    accounts.get(fromAccountNum).block();
                    accounts.get(toAccountNum).block();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public long getBalance(String accountNum) {
        if (accounts.get(accountNum).isBlocked()) {
            System.out.println("Аккаунт заблокирован");
        }
        return accounts.get(accountNum).getMoney();
    }

}
