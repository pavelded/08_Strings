import junit.framework.TestCase;
import Transactions.Account;
import Transactions.Bank;

import java.util.HashMap;
import java.util.Random;

public class BankTest extends TestCase {
    private Bank bank;
    private HashMap<String, Account> accounts = new HashMap<>();
    private Random random = new Random();
    private long sumBeforeTransactions = 0;

    @Override
    public void setUp() {
        for (int i = 0; i < 50; i++) {
            Account account = new Account((int) (Math.random() * 100001), String.valueOf(i));
            accounts.put(String.valueOf(i), account);

            sumBeforeTransactions += account.getMoney();
        }
        bank = new Bank(accounts);
    }

    public void testTransaction() {

        for (int i = 0; i < 100; i++) {
            Thread thread = new Thread(() -> bank.transfer(String.valueOf((int) (Math.random() * 50)),
                    String.valueOf((int) (Math.random() * 50)),
                    (int) (Math.random() * 100001)));
            thread.start();

            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        long sumAfterTransactions = accounts.values().stream().mapToLong(Account::getMoney).sum();
        assertEquals(sumBeforeTransactions, sumAfterTransactions);
    }
}