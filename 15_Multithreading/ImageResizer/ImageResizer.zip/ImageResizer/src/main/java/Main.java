import org.imgscalr.Scalr;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class Main {

    public static void main(String[] args) {
        String srcFolder = "images";
        String dstFolder = "destDir";
        String dstFolder2 = "destDir2";

        File srcDir = new File(srcFolder);

        long start = System.currentTimeMillis();

        File[] files = srcDir.listFiles();

        for (int i = 0; i < Runtime.getRuntime().availableProcessors(); i++) {
            int partLength = files.length / Runtime.getRuntime().availableProcessors();
            File[] threadFiles = new File[partLength];
            int position = 0;
            System.arraycopy(files, position, threadFiles, position, partLength);
            ImageResizer resizer = new ImageResizer(threadFiles, 200, dstFolder2, start);
            resizer.start();
            position += partLength;
        }

        start = System.currentTimeMillis();
        files = srcDir.listFiles();
        for (File file : files) {
            try {
                BufferedImage image = ImageIO.read(file);
                BufferedImage newImage = resize(image, 200, 200);
                File newFile = new File(dstFolder + "/" + file.getName());
                ImageIO.write(newImage, "jpg", newFile);
            } catch (Exception ex) {
            }
        }
        System.out.println("Duration of Scalr repository: " + (System.currentTimeMillis() - start));
    }

    public static BufferedImage resize(BufferedImage src, int targetWidth, int targetHeight) {
        BufferedImage scaledImage = Scalr.resize(src, targetWidth, targetHeight);
        return scaledImage;
    }
}

