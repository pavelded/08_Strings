import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String htmlFile = parseHtmlFile("data/lenta.html");
        Document doc = Jsoup.parse(htmlFile);
        Elements elements = doc.select("img");

        List<String> elementsList = new ArrayList<>();

        for (int i = 0; i < elements.size(); i++) {
            elementsList.add(i, elements.get(i).attr("abs:src"));
        }

        for (String element : elementsList) {
            try {
                URLConnection openConnection = new URL(element).openConnection();
                openConnection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
                BufferedImage image1 = ImageIO.read(openConnection.getInputStream());
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                String[] fileParts = element.split("/");
                String fileName = fileParts[9];
                File file = new File("images/" + fileName);
                file.createNewFile();
                ImageIO.write(image1, "jpg", file);
            }catch (Exception e){
                e.printStackTrace();
            }
            System.out.println(element);
        }
        //String[] urls = elementsList.split();
        //elements.forEach(element ->
                //element.attr("abs:src")));
        //elements.forEach(element ->
            //System.out.println(element.attr("abs:src")));
    }

    private static String parseHtmlFile(String path) {
        StringBuilder builder = new StringBuilder();
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            lines.forEach(line -> builder.append(line + "\n"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return builder.toString();
    }
}
